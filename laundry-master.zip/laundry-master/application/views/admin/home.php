<div class="row">
    <div class="center">
        <center>
            <span style="font-size:45px; margin-bottom:-20px"><b>SISTEM INFORMASI LAUNDRY</b></span><br>
            <span style="font-size:40px; margin-top:-20px"><b><?= strtoupper($data->nama_laundry);?></b></span><br>
            <span style="font-size:17px; font-style:italic;">alamat: <?= $data->alamat_laundry?> Tlp. <?= $data->no_tlp?></span>
</center>
    </div>
</div>